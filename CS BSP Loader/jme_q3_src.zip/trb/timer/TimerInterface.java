/*
 * Created on 07.apr.2005
 *
 */
package trb.timer;

/**
 *
 */
public interface TimerInterface {

	public boolean available();
	
	public long getTime();
	
	public long getTimerResolution();
	
	public void pause();
}
