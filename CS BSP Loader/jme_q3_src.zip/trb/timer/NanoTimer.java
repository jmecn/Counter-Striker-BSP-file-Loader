package trb.timer;


public class NanoTimer implements TimerInterface {

	public boolean available() {
		try {
			System.nanoTime();
		} catch (Throwable t) {
			return false;
		}
		
		return true;
	}
	
	public long getTime() {
		return System.nanoTime();
	}
	
	public long getTimerResolution() {
        return 1000000000L;
	}
	
	public void pause() {
		Thread.yield();
	}
	
	
	public String toString() {
		return "NanoTimer";
	}
}
