/*
 * Copyright (c) 2003-2005 jMonkeyEngine
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * * Neither the name of 'jMonkeyEngine' nor the names of its contributors 
 *   may be used to endorse or promote products derived from this software 
 *   without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package trb.jme.quake3;

import java.io.IOException;

import trb.jme.imaging.TextureLoader;

import com.jme.app.SimpleGame;
import com.jme.input.FirstPersonHandler;
import com.jme.math.Vector3f;
import com.jme.scene.state.CullState;
import com.jme.util.LoggingSystem;

public class JMESimpleQuakeRenderer extends SimpleGame {
    Quake3Converter converter;
    Vector3f eyePos = new Vector3f();
    /**
     * Runs the simple q3 level viewer.
     */
    public static void main(String[] args) {
        LoggingSystem.getLoggingSystem().loggerOn(false);
        try {
            JMESimpleQuakeRenderer test = new JMESimpleQuakeRenderer();
            test.setDialogBehaviour(ALWAYS_SHOW_PROPS_DIALOG);
            test.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void simpleUpdate() {
        Vector3f camLoc = cam.getLocation();
        eyePos.set(camLoc);
        converter.setVisibility(eyePos, true);
    }
    
    protected void simpleInitGame() {    
        display.getRenderer().getQueue().setTwoPassTransparency(false);
        cam.setFrame(new Vector3f(-14, 1.5f, -2.5f), new Vector3f(0, 0, 1), new Vector3f(0, 1, 0), new Vector3f(-1, 0, 0));
        cam.update();
        lightState.setEnabled(false);

        input = new FirstPersonHandler(cam, 8, 1);
        
        CullState cullState = display.getRenderer().createCullState();
        cullState.setCullMode(CullState.CS_FRONT);
        rootNode.setRenderState(cullState);

        // load quake 3 level
        TextureLoader.getInstance().registerPath("data/qdata/");
        Quake3Loader loader = new Quake3Loader();
        try {
            loader.load("data/qdata/pdmq3duel5.bsp");
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        converter = new Quake3Converter();
        converter.convert(loader, display);
        rootNode.attachChild(converter.getRoot());
        rootNode.lock(display.getRenderer());
    }

    protected void cameraPerspective() {
        cam.setFrustumPerspective(55.0f, (float) display.getWidth()
                / (float) display.getHeight(), .1f, 2000);
        cam.setParallelProjection(false);
        cam.update();
    }
}

