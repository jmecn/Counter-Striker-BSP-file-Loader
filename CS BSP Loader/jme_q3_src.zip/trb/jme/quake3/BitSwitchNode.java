package trb.jme.quake3;

import com.jme.renderer.Renderer;
import com.jme.scene.*;

import java.util.BitSet;

/**
 * <code>BSwitchNode</code> defines a node that maintains a set of active children
 */
public class BitSwitchNode extends Node {
	private static final long serialVersionUID = 1L;

	protected BitSet bitSet;

	/**
	 * Constructor instantiates a new <code>BitSwitchNode</code> object. The name
	 * of the node is provided during construction.
	 * 
	 * @param name the name of the node.
	 * @param bitSet contains which children to render. Length must match number of children.
	 */
	public BitSwitchNode(String name, BitSet bitSet) {
		super(name);
		this.bitSet = bitSet;
	}
	
	
	/**
	 * Draws the children that is enabled by the bitset.
	 * This function should be called internally only.
	 * 
	 * @param r
	 *            The render system to draw the child.
	 */
	public void draw(Renderer r) {
		for (int i=getQuantity(); --i>=0; ) {
            if (bitSet.get(i)) {
                getChild(i).onDraw(r);
            }
		}
	}
}