/**
 * Copyright (c) 2003, Xith3D Project Group
 * All rights reserved.
 *
 * Portions based on the Java3D interface, Copyright by Sun Microsystems.
 * Many thanks to the developers of Java3D and Sun Microsystems for their
 * innovation and design.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Neither the name of the 'Xith3D Project Group' nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) A
 * RISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE
 *
 */
package trb.jme.quake3;

import trb.jme.imaging.TextureLoader;
import trb.timer.TRBTimer;

import com.jme.input.FirstPersonHandler;
import com.jme.input.InputSystem;
import com.jme.input.KeyBindingManager;
import com.jme.input.KeyInput;
import com.jme.input.MouseInput;
import com.jme.math.Vector3f;
import com.jme.renderer.Camera;
import com.jme.renderer.ColorRGBA;
import com.jme.scene.Node;
import com.jme.scene.state.CullState;
import com.jme.scene.state.ZBufferState;
import com.jme.system.DisplaySystem;
import com.jme.util.LoggingSystem;
import com.jme.util.Timer;
import com.jme.util.geom.Debugger;


public class JMEQuake3Renderer {

    long frames = 0;
    double totalTime = getTime();
    double lastTime = totalTime;
    
    public void init() throws Exception {
    	LoggingSystem.getLoggingSystem().loggerOn(false);
    	
		DisplaySystem display = null;
		try {
			display = DisplaySystem.getDisplaySystem("LWJGL");
			display.setMinDepthBits(8);
			display.setMinStencilBits(0);
			display.setMinAlphaBits(0);
			display.setMinSamples(0);
			display.createWindow(800, 600, 32, 60, false);
			display.getRenderer().setBackgroundColor(ColorRGBA.black);
            display.getRenderer().getQueue().setTwoPassTransparency(false);

			// Create a camera specific to the DisplaySystem that works with the display's width and height
			Camera cam = display.getRenderer().createCamera(display.getWidth(), display.getHeight());
			cam.setFrustumPerspective(55.0f, (float) display.getWidth() / (float) display.getHeight(), 0.1f, 2000);
            cam.setParallelProjection(false);
			cam.setFrame(new Vector3f(-14, 1.5f, -2.5f), new Vector3f(0, 0, 1), new Vector3f(0, 1, 0), new Vector3f(-1, 0, 0));
			cam.update();
			display.getRenderer().setCamera(cam);

			// Create a basic input controller.
            FirstPersonHandler input = new FirstPersonHandler(cam, 8, 1);

			// Get a high resolution timer for FPS updates.
			Timer timer = Timer.getTimer("LWJGL");

			KeyBindingManager.getKeyBindingManager().set("exit", KeyInput.KEY_ESCAPE);
			KeyBindingManager.getKeyBindingManager().set("toggle_bounds", KeyInput.KEY_B);
			KeyBindingManager.getKeyBindingManager().set("use_pvs", KeyInput.KEY_F1);
			KeyBindingManager.getKeyBindingManager().set("freeze_pvs", KeyInput.KEY_F2);

			// Create rootNode
			Node rootNode = new Node("rootNode");

			// Create a ZBuffer to display pixels closest to the camera above
			ZBufferState buf = display.getRenderer().createZBufferState();
			buf.setFunction(ZBufferState.CF_LEQUAL);
			rootNode.setRenderState(buf);

			// load quake 3 level
	        //TextureLoader.getInstance().registerPath("C:/java/xith3d/xith3d-q3/demo/data/");
	        TextureLoader.getInstance().registerPath("./data/qdata/");
	        Quake3Loader loader = new Quake3Loader();
	        //loader.load("C:/java/xith3d/xith3d-q3/demo/data/pdmq3duel5.bsp");
	        loader.load("./data/qdata/pdmq3duel5.bsp");
	        Quake3Converter converter = new Quake3Converter();
	        converter.convert(loader, display);
	        rootNode.attachChild(converter.getRoot());

            CullState cState = display.getRenderer().createCullState();
            cState.setCullMode(CullState.CS_FRONT);
            rootNode.setRenderState(cState);
            
			// Update geometric and rendering information for both the rootNode and fpsNode.
			rootNode.updateGeometricState(0.0f, true);
			rootNode.updateRenderState();

			long frames = 0;
	        double totalTime = getTime();

			//main loop
	        boolean showBounds = false;
	        boolean usePVS = true;
	        boolean freezePVS = false;
	        
            rootNode.lock(display.getRenderer());
			boolean finished = false;
            Vector3f eyePos = new Vector3f();
            float tpf = 0;
			while (!finished && !display.isClosing()) {
				//handle input events prior to updating the scene
				InputSystem.update();

				// Recalculate the framerate.
				timer.update();
                tpf = timer.getTimePerFrame();
                
				// Check for key/mouse updates.
				input.update(tpf);

				if (KeyBindingManager.getKeyBindingManager().isValidCommand("exit", false)) {
					finished = true;
				}
		        if (KeyBindingManager.getKeyBindingManager().isValidCommand("toggle_bounds", false)) {
		            showBounds = !showBounds;
		        }
		        if (KeyBindingManager.getKeyBindingManager().isValidCommand("use_pvs", false)) {
            		usePVS = !usePVS;
            		System.out.println("usePVS: "+usePVS);
            	}
		        if (KeyBindingManager.getKeyBindingManager().isValidCommand("freeze_pvs", false)) {
            		freezePVS = !freezePVS;
            		System.out.println("freezePVS: "+freezePVS);
            	}

	            if (!freezePVS) {
					Vector3f camLoc = cam.getLocation();
                    eyePos.set(camLoc.x, camLoc.y, camLoc.z);
		            converter.setVisibility(eyePos, usePVS);
	            }

				// Update controllers/render states/transforms/bounds for rootNode.
				rootNode.updateGeometricState(tpf, true);

				// Clears the previously rendered information.
				display.getRenderer().clearBuffers();

				if (!showBounds) {
                    // Draw the rootNode and all its children.
                    display.getRenderer().draw(rootNode);
				} else {
                    Debugger.drawBounds(rootNode, display.getRenderer(), true);
				}

				//swap buffers
				display.getRenderer().displayBackBuffer();

	            // print fps
	        	double currentTime = getTime();
	        	lastTime = currentTime;
	            
	        	double tTime = currentTime - totalTime;
	            frames++;
	            if (tTime>1) {
	                System.out.println(""+(int)(frames / tTime));
	                totalTime = getTime();
	                frames=0;
	            }

				Thread.yield();
			}
		} catch (Throwable t) {
			t.printStackTrace();
		}

		// cleanup
		KeyInput.destroyIfInitalized();
		MouseInput.destroyIfInitalized();

		if (display != null) {
			display.reset();
			display.close();
		}
		System.exit(0);
    }

	
	/**
	 * Gets the current time in seconds
	 */
	private static double getTime() {
		return TRBTimer.getTime() / (double) TRBTimer.getTimerResolution();
	}

    
	/**
	 * Runs the simple q3 level viewer.
	 */
	public static void main(String[] args) {
        try {
        	TRBTimer.init();
            JMEQuake3Renderer test = new JMEQuake3Renderer();
            test.init();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
